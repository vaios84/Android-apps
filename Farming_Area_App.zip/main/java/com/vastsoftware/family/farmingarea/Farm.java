package com.vastsoftware.family.farmingarea;

import android.Manifest;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Spinner;
import android.widget.TextView;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;

import android.widget.Toast;

public class Farm  extends AppCompatActivity implements LocationListener{

    private TextView txtLat, txtSpeed, avgSpeed , prod, avgProd, cmplArea, remArea;

    private Chronometer chronometer;
    private Button But04, But05, But06, B_add;
    private TextView tv06;
    private Spinner sp01;

    private float x=0, speedsum=0;
    private int moveflag=0, counter=0;

    private float coord1 =0, coord2=0;

    private long timeWhenStopped = 0;

    protected LocationManager locationManager;

    //code for formating all results(coords, speed, avg speed etc) as follows with three decimal points
    String pattern = "###,###.##";
    DecimalFormat decimalFormat = new DecimalFormat(pattern);

    //code for getting the passing data from FarmConfig activity
    private String strlandSize, strtoolWidth;
    private float landSize, toolWidth;
    private NotificationManager mNotificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm);

        //code for getting the passing data from FarmConfig activity
        Intent intentExtras = getIntent();
        strlandSize = intentExtras.getStringExtra("edText2Value");
        strtoolWidth = intentExtras.getStringExtra("edText6Value");
        landSize = Float.valueOf(strlandSize);
        toolWidth = Float.valueOf(strtoolWidth);

        //this code will keep the screen on while this class of the app is running
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //request location update but always check if the method getLastKnownLocation
        //has thrown a null exception. cause this is going to make the app crash

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

          // Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
          //if (lastKnownLocation != null) {
          //  locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000, 2, this);
          //}


        txtLat = (TextView) findViewById(R.id.textview1);
        txtSpeed = (TextView) findViewById(R.id.textviewspeed);
        avgSpeed = (TextView) findViewById(R.id.textviewavgspeed);
        prod = (TextView) findViewById(R.id.textviewproduct);
        avgProd = (TextView) findViewById(R.id.textviewavgproduct);
        cmplArea = (TextView) findViewById(R.id.completed_area);
        remArea = (TextView) findViewById(R.id.remain_area);

        chronometer = (Chronometer) findViewById(R.id.chronometer);
        But04 = (Button) findViewById(R.id.start_button);
        But05 = (Button) findViewById(R.id.stop_button);
        But06 = (Button) findViewById(R.id.main_menu);
        B_add = (Button) findViewById(R.id.add_point);

        tv06 = (TextView) findViewById(R.id.textView6);
        sp01= (Spinner) findViewById(R.id.spinner1);

        But04.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showGPSToast(v);
                chronometer.setBase(SystemClock.elapsedRealtime());
                chronometer.start();
                moveflag=0;
            }
        });

        But05.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                chronometer.stop();
            }
        });

        But06.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showDataSaveToast(v);
                Intent intent = new Intent(Farm.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        B_add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    //Write a file to the disk
                    FileOutputStream fOut2 = null;
                    FileOutputStream fOut3 = null;
                    try {
                        fOut2 = openFileOutput("latLogfile.txt", MODE_APPEND);
                        fOut3 = openFileOutput("longLogfile.txt", MODE_APPEND);

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    OutputStreamWriter osw2 = new OutputStreamWriter(fOut2);
                    OutputStreamWriter osw3 = new OutputStreamWriter(fOut3);

                    // Write the location strings to the files
                    osw2.write(" " + String.valueOf(coord1));
                    osw3.write(" " + String.valueOf(coord2));

                    // ensure that everything is really written out and close
                    osw2.flush();
                    osw2.close();
                    osw3.flush();
                    osw3.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    public void onLocationChanged(Location location) {
        //location
        txtLat = (TextView) findViewById(R.id.textview1);
        coord1 = (float) location.getLatitude();
        coord2 = (float) location.getLongitude();

        //code for formating the two coorrds as follows ###.##
        String formatcoord1 = decimalFormat.format(coord1);
        String formatcoord2 = decimalFormat.format(coord2);
        txtLat.setText("Lat: " + formatcoord1 + "\n" + "Long: " + formatcoord2);
        //speed
        txtSpeed = (TextView) findViewById(R.id.textviewspeed);
        x= location.getSpeed();
        String formatx = decimalFormat.format(x*3.6);
        txtSpeed.setText("speed: " + Float.valueOf(formatx) + " km/h");

        //average speed
        counter++;
        speedsum = speedsum + x;
        String formatavgspeed = decimalFormat.format( (speedsum/counter)*3.6);
        avgSpeed.setText("avg_speed: " + Float.valueOf(formatavgspeed) + " km/h" );

        //productivity
        String formatpr = decimalFormat.format(x*toolWidth*3.6);
        prod.setText("product: "+ Float.valueOf(formatpr) + " strm/h");

        String formatavgpr = decimalFormat.format((speedsum/counter)*toolWidth*3.6);
        avgProd.setText("avg_product: " + Float.valueOf(formatavgpr) + " strm/h");

        //completed area and remaining area
        //stop the time when we are not moving
        // this way we have more accurate calculations for completed area & remain area
        if (moveflag==0 && x<2){
            timeWhenStopped = chronometer.getBase() - SystemClock.elapsedRealtime();
            chronometer.stop();
            moveflag=1;
        }

        if(x>=2) {
            if(moveflag==1 && x>=2){
                chronometer.setBase(SystemClock.elapsedRealtime() + timeWhenStopped);
                chronometer.start();

            }
            moveflag=0;
        }

        //read elapsed time from chronometer
        long elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
        float seconds = (float)(elapsedMillis/1000);

        String formatcomplete = decimalFormat.format((speedsum/counter)*toolWidth*seconds*0.001);
        String formatremain = decimalFormat.format(landSize-(speedsum/counter)*toolWidth*seconds*0.001);
        if(Float.valueOf(formatcomplete)<=landSize && Float.valueOf(formatremain)>=0){
            cmplArea.setText("complete: " + Float.valueOf(formatcomplete) + " strm");
            remArea.setText("remain: " + Float.valueOf(formatremain) + " strm");
        }else{
            cmplArea.setText("complete: " + landSize + " strm");
            remArea.setText("remain: " + 0 + " strm");

        }

        //always check if we are near a special point
        //if positive then create notification
        //if(counter%10 ==0) checkProximity(coord1,coord2);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {Log.d("Latitude", "status"); }

    @Override
    public void onProviderEnabled(String provider) {
        Log.d("Latitude","enable");
    }

    @Override
    public void onProviderDisabled(String provider) {
        Log.d("Latitude", "disable");
    }

	

	
	protected void showGPSToast(View view){
        Toast.makeText(this, "Always have your device GPS enabled!", Toast.LENGTH_LONG).show();

    }

    protected void showDataSaveToast(View view){
        Toast.makeText(this, "Data saved successfully", Toast.LENGTH_LONG).show();

    }


    public void checkProximity(float a, float b){
        int i;

        //reading lat file
        FileInputStream fIn = null;
        try {
            fIn = openFileInput("latLogfile.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        InputStreamReader isr = new InputStreamReader(fIn);
        // Prepare a char-Array that will hold the chars we read back in
        char[] inputBuffer = new char[3000];
        // Fill the Buffer with data from the file
        try {
            isr.read(inputBuffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Transform the chars to a String
        String readString = new String(inputBuffer);
        String subreadString1[] = readString.split(" ");
        ArrayList<String> mylist1= new ArrayList<>(Arrays.asList(subreadString1));


        //reading longitude file
        FileInputStream fIn2 = null;
        try {
            fIn2 = openFileInput("longLogfile.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        InputStreamReader isr2 = new InputStreamReader(fIn2);
        // Prepare a char-Array that will hold the chars we read back in
        char[] inputBuffer2 = new char[3000];
        // Fill the Buffer with data from the file
        try {
            isr2.read(inputBuffer2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Transform the chars to a String
        String readString2 = new String(inputBuffer2);
        String subreadString2[] = readString2.split(" ");
        ArrayList<String> mylist2= new ArrayList<>(Arrays.asList(subreadString2));

            for(i=0; i<mylist1.size(); i++){
                float j = Float.valueOf(mylist1.get(i));
                float k = Float.valueOf(mylist2.get(i));

                if(Math.abs(a-j)<= 0.0005 || Math.abs(b-k)<= 0.0005) {

                    NotificationCompat.Builder nBuilder = new NotificationCompat.Builder(this);
                    nBuilder.setContentTitle("Alarm!");
                    nBuilder.setContentText("Proceed with caution! Approaching a special point!");
                    nBuilder.setTicker("New Message");
                    nBuilder.setAutoCancel(true);
                    nBuilder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
                    nBuilder.setSmallIcon(R.drawable.caution);

                    Intent intent = new Intent(this, Farm.class);

                    TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
                    stackBuilder.addParentStack(Farm.class);

                    stackBuilder.addNextIntent(intent);

                    PendingIntent pendingIntent = stackBuilder.getPendingIntent(0,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    nBuilder.setContentIntent(pendingIntent);

                    mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                    mNotificationManager.notify(1000, nBuilder.build());

                }

            }

    }


}
