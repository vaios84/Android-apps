package com.vastsoftware.family.farmingarea;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class Contact extends AppCompatActivity {
    TextView tv02, tv03,tv04,tv05;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        tv02 = (TextView) findViewById(R.id.textView2);
        tv03 = (TextView) findViewById(R.id.textView3);
        tv04 = (TextView) findViewById(R.id.textView4);
        tv05 = (TextView) findViewById(R.id.textView5);
    }
}
