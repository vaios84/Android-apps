package com.vastsoftware.family.farmingarea;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Farmconfig extends AppCompatActivity{
    private Button But07;
    private TextView tv07,tv08,tv09,tv10,tv11,tv12,tv13 ;
    private EditText edt01, edt02, edt03, edt04, edt05,  edt06;
    private String edText1Value,edText2Value,edText3Value,edText4Value,edText5Value,edText6Value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmconfig);

        tv07 = (TextView) findViewById(R.id.textView7);
        tv08 = (TextView) findViewById(R.id.textView8);
        tv09 = (TextView) findViewById(R.id.textView9);
        tv10 = (TextView) findViewById(R.id.textView10);
        tv11 = (TextView) findViewById(R.id.textView11);
        tv12 = (TextView) findViewById(R.id.textView12);
        tv13 = (TextView) findViewById(R.id.textView13);

        edt01 = (EditText) findViewById(R.id.editText1);
        edt02 = (EditText) findViewById(R.id.editText2);
        edt03 = (EditText) findViewById(R.id.editText3);
        edt04 = (EditText) findViewById(R.id.editText4);
        edt05 = (EditText) findViewById(R.id.editText5);
        edt06 = (EditText) findViewById(R.id.editText6);

        But07 = (Button) findViewById(R.id.button7);

        But07.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                edText1Value = edt01.getText().toString(); // get all the strings that have been inserted by the user
                edText2Value = edt02.getText().toString();
                edText3Value = edt03.getText().toString();
                edText4Value = edt04.getText().toString();
                edText5Value = edt05.getText().toString();
                edText6Value = edt06.getText().toString();

                if (edText1Value.length()==0 || edText2Value.length()==0 || edText6Value.length()==0) showToast(v);

                if ((edText1Value.length()>0 && edText2Value.length()>0 && edText6Value.length()>0)) {
                    try { // catches IOException below

                        // ##### Write a file to the disk #####

                        FileOutputStream fOut = null;
                        try {
                            fOut = openFileOutput("logfile.txt", MODE_APPEND);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        OutputStreamWriter osw = new OutputStreamWriter(fOut);
                        // Write the string to the file


                        if (edText1Value.length() > 0 || edText2Value.length() > 0 || edText3Value.length() > 0
                                || edText4Value.length() > 0 || edText5Value.length() > 0 || edText6Value.length() > 0){
                            Calendar c = Calendar.getInstance();
                            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
                            String formattedDate = df.format(c.getTime());
                            osw.write("# " + formattedDate + "/");
                        }
                            osw.write(edText1Value);
                            osw.write("/");

                            osw.write(edText2Value + " str");
                            osw.write("/");

                        if (edText3Value.length() > 0) {
                            osw.write(edText3Value);
                            osw.write("/");
                        }

                        if (edText4Value.length() > 0) {
                            osw.write(edText4Value + " hp");
                            osw.write("/");
                        }

                        if (edText5Value.length() > 0) {
                            osw.write(edText5Value);
                            osw.write("/");
                        }
                            osw.write(edText6Value + " m");

                            osw.write("//");
                            osw.write("\n");
                            /* ensure that everything is really written out and close */
                            osw.flush();
                            osw.close();

                        showGPSToast(v);

                        Intent openFarm = new Intent("android.intent.action.FARM");
                        //code for adding data in the intent and passing this data at Farm activity
                        openFarm.putExtra("edText2Value" , edText2Value);
                        openFarm.putExtra("edText6Value" , edText6Value);
                        startActivity(openFarm);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
        });

    }

    public void showToast(View view){
        Toast.makeText(this, "Field Name, Size and Tool Width can't be blank!", Toast.LENGTH_LONG).show();

    }

    protected void showGPSToast(View view){
        Toast.makeText(this, "Please have your device GPS enabled!", Toast.LENGTH_LONG).show();

    }

}
