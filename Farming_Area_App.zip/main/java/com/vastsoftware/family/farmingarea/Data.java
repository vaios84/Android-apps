package com.vastsoftware.family.farmingarea;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class Data extends AppCompatActivity {
    TextView tv14;
    EditText edt07;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        tv14 = (TextView)findViewById(R.id.textView14);
        edt07 = (EditText)findViewById(R.id.editText7);

        try {
            // Write a file to the disk
            FileOutputStream fOut = null;
            try {
                fOut = openFileOutput("logfile.txt", MODE_APPEND);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            OutputStreamWriter osw = new OutputStreamWriter(fOut);

            osw.flush();
            osw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


        // Read the file back in
        FileInputStream fIn = null;

        try {
            fIn = openFileInput("logfile.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        InputStreamReader isr = new InputStreamReader(fIn);
        // Prepare a char-Array that will hold the chars we read back in
        char[] inputBuffer = new char[3000];
        // Fill the Buffer with data from the file
        try {
            isr.read(inputBuffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Transform the chars to a String
        String readString = new String(inputBuffer);
        edt07.setText(readString);

    }
}
