package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//FOR ADS
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Length extends Activity{
	int flag;
	double metres, km, feet, inches, miles, seaMiles, yards = 0;
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3, edText4, edText5, edText6, edText7;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_length);
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest); 
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.LENGTH");
			Intent openLENGTH = new Intent (Length.this, spClass);
			startActivity(openLENGTH);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
		edText4 = (EditText) findViewById(R.id.editText4);
		edText5 = (EditText) findViewById(R.id.editText5);
		edText6 = (EditText) findViewById(R.id.editText6);
		edText7 = (EditText) findViewById(R.id.editText7);
		
	 convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (flag ==0){
				
				String edText1Value = edText1.getText().toString();//Then get the string that is currently being displayed
				String edText2Value = edText2.getText().toString();
				String edText3Value = edText3.getText().toString();
				String edText4Value = edText4.getText().toString();	
				String edText5Value = edText5.getText().toString();
				String edText6Value = edText6.getText().toString();
				String edText7Value = edText7.getText().toString();
			
					if (edText1Value.isEmpty() != true){
						metres = Double.parseDouble(edText1Value);//Then parse it for a double
						edText1.setText(metres +" m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
						
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");
											
						flag=1;
					} else if (edText2Value.isEmpty() != true){
						km = Double.parseDouble(edText2Value);//Then parse it for a double
						edText2.setText(km +" km");
						
						metres = 1000* km;
						edText1.setText(metres + " m");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
						
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");
						
						
						flag=1;
					} else if (edText3Value.isEmpty() != true){
						feet = Double.parseDouble(edText3Value);//Then parse it for a double
						edText3.setText(feet +" ft");
						
						metres = 0.3048*feet;
						edText1.setText(metres + " m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
												
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
						
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");
						
						flag=1;
					} else if (edText4Value.isEmpty() != true){
						inches = Double.parseDouble(edText4Value);//Then parse it for a double
						edText4.setText(inches +" in");
						
						metres = 0.0254*inches;
						edText1.setText(metres + " m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
						
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");
																	
						flag=1;
					} 	else if (edText5Value.isEmpty() != true){
						miles = Double.parseDouble(edText5Value);//Then parse it for a double
						edText5.setText(miles + " mil");
						
						metres = 1609.344*miles;
						edText1.setText(metres +" m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
						
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");					
						
						flag=1;
					} else if (edText6Value.isEmpty() != true){
						seaMiles = Double.parseDouble(edText6Value);//Then parse it for a double
						edText6.setText(seaMiles +" seaMil");
						
						metres = 1852 * seaMiles;
						edText1.setText(metres +" m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
												
						yards = 1.09361*metres;
						edText7.setText(yards + " yrd");
						
						flag=1;
					} else if (edText7Value.isEmpty() != true){
						yards = Double.parseDouble(edText7Value);//Then parse it for a double
						edText7.setText(yards +" yrd");
						
						metres = 0.9144 *yards;
						edText1.setText(metres +" m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						miles = 0.0006214*metres;
						edText5.setText(miles + " mil");
						
						seaMiles = 0.00053996*metres;
						edText6.setText(seaMiles + " seaMil");
																							
						flag=1;
					}
					
				} else{
					edText1.setText("");
					edText2.setText("");
					edText3.setText("");
					edText4.setText("");
					edText5.setText("");
					edText6.setText("");
					edText7.setText("");
					flag = 0;					
				}
															
			 }		
			
		 });	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				edText4.setText("");	
				edText5.setText("");
				edText6.setText("");
				edText7.setText("");
				flag = 0;
			}			
			
		});
		
		
	}


}
