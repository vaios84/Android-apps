package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//FOR ADS
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Metric extends Activity{
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3, edText4, edText5, edText6, edText7, edText8, edText9, edText10;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_metric);
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest); 
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.METRIC");
			Intent openMETRIC = new Intent (Metric.this, spClass);
			startActivity(openMETRIC);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
		edText4 = (EditText) findViewById(R.id.editText4);
		edText5 = (EditText) findViewById(R.id.editText5);
		edText6 = (EditText) findViewById(R.id.editText6);
		edText7 = (EditText) findViewById(R.id.editText7);
		edText8 = (EditText) findViewById(R.id.editText8);
		edText9 = (EditText) findViewById(R.id.editText9);
		edText10 =(EditText) findViewById(R.id.editText10);
		
		convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			edText1.setText("pW = 1E-12 Watt");
			edText2.setText("nW = 1E-9 Watt");
			edText3.setText("μW = 0.000001 Watt");
			edText4.setText("mW = 0.001 Watt");
			edText5.setText("cW = 0.01 Watt");
			edText6.setText("dW = 0.1 Watt");
			edText7.setText("KW = 1000 Watt");
			edText8.setText("MW = 1000000 Watt");
			edText9.setText("GW = 1E+9 Watt");
			edText10.setText("TW = 1E+12 Watt");
																	
			}		
			
		});	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				edText4.setText("");	
				edText5.setText("");
				edText6.setText("");
				edText7.setText("");
				edText8.setText("");
				edText9.setText("");
				edText10.setText("");
				
			}			
			
		});
		
		
	}


}
