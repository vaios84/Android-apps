package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//FOR ADS
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Height extends Activity{
	int flag;
	double metres, km, feet, inches = 0;
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3, edText4;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_height);
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest); 
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.HEIGHT");
			Intent openHEIGHT = new Intent (Height.this, spClass);
			startActivity(openHEIGHT);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
		edText4 = (EditText) findViewById(R.id.editText4);
		
		
	 convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (flag ==0){
				
				String edText1Value = edText1.getText().toString();//Then get the string that is currently being displayed
				String edText2Value = edText2.getText().toString();
				String edText3Value = edText3.getText().toString();
				String edText4Value = edText4.getText().toString();	
			
					if (edText1Value.isEmpty() != true){
						metres = Double.parseDouble(edText1Value);//Then parse it for a double
						edText1.setText(metres +" m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
											
						flag=1;
					} else if (edText2Value.isEmpty() != true){
						km = Double.parseDouble(edText2Value);//Then parse it for a double
						edText2.setText(km +" km");
						
						metres = 1000* km;
						edText1.setText(metres + " m");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
						
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						
						flag=1;
					} else if (edText3Value.isEmpty() != true){
						feet = Double.parseDouble(edText3Value);//Then parse it for a double
						edText3.setText(feet +" ft");
						
						metres = 0.3048*feet;
						edText1.setText(metres + " m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
												
						inches = 39.3701*metres;
						edText4.setText(inches + " in");
						
						flag=1;
					} else if (edText4Value.isEmpty() != true){
						inches = Double.parseDouble(edText4Value);//Then parse it for a double
						edText4.setText(inches +" in");
						
						metres = 0.0254*inches;
						edText1.setText(metres + " m");
						
						km = 0.001*metres;
						edText2.setText(km + " km");
						
						feet = 3.28084*metres;
						edText3.setText(feet + " ft");
																	
						flag=1;
					} 	
					
				}else{
					edText1.setText("");
					edText2.setText("");
					edText3.setText("");
					edText4.setText("");										
					flag = 0;					
				}
															
			 }		
			
		 });	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				edText4.setText("");								
				flag = 0;
			}			
			
		});
		
		
	}


}
