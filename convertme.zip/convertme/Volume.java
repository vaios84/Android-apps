package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//FOR ADS
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Volume extends Activity{
	int flag;
	double liter, barrel, cuft, cuin, cume, cuce, gallon, floz, quart  = 0;
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3, edText4, edText5, edText6, edText7, edText8, edText9;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_volume);
		
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest); 
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.VOLUME");
			Intent openVOLUME = new Intent (Volume.this, spClass);
			startActivity(openVOLUME);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
		edText4 = (EditText) findViewById(R.id.editText4);
		edText5 = (EditText) findViewById(R.id.editText5);
		edText6 = (EditText) findViewById(R.id.editText6);
		edText7 = (EditText) findViewById(R.id.editText7);
		edText8 = (EditText) findViewById(R.id.editText8);
		edText9 = (EditText) findViewById(R.id.editText9);
		
	 convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (flag ==0){
				
				String edText1Value = edText1.getText().toString();//Then get the string that is currently being displayed
				String edText2Value = edText2.getText().toString();
				String edText3Value = edText3.getText().toString();
				String edText4Value = edText4.getText().toString();	
				String edText5Value = edText5.getText().toString();
				String edText6Value = edText6.getText().toString();
				String edText7Value = edText7.getText().toString();
				String edText8Value = edText8.getText().toString();
				String edText9Value = edText9.getText().toString();
							
					if (edText1Value.isEmpty() != true){
						liter = Double.parseDouble(edText1Value); //Then parse it for a double
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");					
						
						flag=1;
					} else if (edText2Value.isEmpty() != true){
						barrel = Double.parseDouble(edText2Value); //Then parse it for a double
						edText2.setText(barrel + " bl");				
						
						liter = 158.98729493*barrel;
						edText1.setText(liter + " lt");					
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");								
						
						flag=1;
					} else if (edText3Value.isEmpty() != true){						
						cuft = Double.parseDouble(edText3Value); //Then parse it for a double
						edText3.setText(cuft + " cuft");
						
						liter = 28.31684659*cuft;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");			
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");						
						
						flag=1;
					} else if (edText4Value.isEmpty() != true){
						cuin = Double.parseDouble(edText4Value); //Then parse it for a double
						edText4.setText(cuin + " cuin");
						
						liter = 0.016387064*cuin;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");		
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");						
																	
						flag=1;
					} 	else if (edText5Value.isEmpty() != true){
						cume = Double.parseDouble(edText5Value); //Then parse it for a double
						edText5.setText(cume + " cume");
						
						liter = 1000*cume;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");					
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");										
						
						flag=1;
					} else if (edText6Value.isEmpty() != true){
						cuce = Double.parseDouble(edText6Value); //Then parse it for a double
						edText6.setText(cuce + " cuce"); 
						 
						liter = 0.001*cuce;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");				
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");					
						
						flag=1;
					} else if (edText7Value.isEmpty() != true){
						gallon = Double.parseDouble(edText7Value); //Then parse it for a double
						edText7.setText(gallon + " gal");
						
						liter = 3.785411784*gallon;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");				
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");						
																							
						flag=1;
					}else if (edText8Value.isEmpty() != true){
						floz = Double.parseDouble(edText8Value); //Then parse it for a double
						edText8.setText(floz + " floz");
						
						liter = 0.0295735296*floz;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");				
						
						quart = 1.05668821*liter;
						edText9.setText(quart + " quart");				
																							
						flag=1;
					}else if (edText9Value.isEmpty() != true){
						quart = Double.parseDouble(edText9Value); //Then parse it for a double
						edText9.setText(quart + " quart");	
						
						liter = 0.94635295*quart;
						edText1.setText(liter + " lt");
						
						barrel = 0.006289811*liter;
						edText2.setText(barrel + " bl");
						
						cuft = 0.035314667*liter;
						edText3.setText(cuft + " cuft");
						
						cuin = 61.023744095*liter;
						edText4.setText(cuin + " cuin");
						
						cume = 0.001*liter;
						edText5.setText(cume + " cume");
						
						cuce = 1000*liter;
						edText6.setText(cuce + " cuce");
						
						gallon = 0.2641720524*liter;
						edText7.setText(gallon + " gal");
						
						floz = 33.814022702*liter;
						edText8.setText(floz + " floz");				
						
						flag=1;
					}
					
				} else{
					edText1.setText("");
					edText2.setText("");
					edText3.setText("");
					edText4.setText("");
					edText5.setText("");
					edText6.setText("");
					edText7.setText("");
					edText8.setText("");
					edText9.setText("");
					flag = 0;					
				}
															
			 }		
			
		 });	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				edText4.setText("");	
				edText5.setText("");
				edText6.setText("");
				edText7.setText("");
				edText8.setText("");
				edText9.setText("");
				flag = 0;
			}			
			
		});
		
		
	}


}
