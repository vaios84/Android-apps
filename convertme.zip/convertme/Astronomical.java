package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Astronomical extends Activity{
	TextView astroTV1, astroTV2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_astronomical);
		
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest);
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.ASTRONOMICAL");
			Intent openASTRO = new Intent (Astronomical.this, spClass);
			startActivity(openASTRO);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 
		
		astroTV1 = (TextView) findViewById(R.id.tv01);
		astroTV2 = (TextView) findViewById(R.id.tv02);
	}

}
