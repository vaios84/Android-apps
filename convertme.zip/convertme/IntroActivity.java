package com.softwarevast.convertme;

import android.app.Activity;
import android.content.Intent;
//import android.media.MediaPlayer;
import android.os.Bundle;
import twisted_goat.convert_me.R;

public class IntroActivity extends Activity{
	//MediaPlayer mySong;
	
	@Override
	protected void onCreate(Bundle vaiosInstance) {
		// TODO Auto-generated method stub
		super.onCreate(vaiosInstance);
		setContentView(R.layout.activity_intro);//activity_intro einai to onoma tou antistoixou xml file
		//mySong = MediaPlayer.create(Intro.this,R.raw.piano1);
		//mySong.start();
		
		Thread timer = new Thread(){
			public void run(){
				try{
					sleep(3000);
				}catch(InterruptedException e){
					e.printStackTrace();
				}finally{
					Intent openMAIN = new Intent("com.softwarevast.convertme.MAINACTIVITY");
					startActivity(openMAIN);					
				}			
				
			}
			
		};
		timer.start();				
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		//mySong.release();
		finish();
	}
}
