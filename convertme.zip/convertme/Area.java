package com.softwarevast.convertme;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;


public class Area extends Activity{
	
	int flag;
	double sqm, sqkm, sqmile, hectare, sqinch, sqfeet, sqyard, acre = 0;
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3, edText4, edText5, edText6, edText7, edText8;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_area);
		
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest);
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.AREA");
			Intent openAREA = new Intent (Area.this, spClass);
			startActivity(openAREA);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
		edText4 = (EditText) findViewById(R.id.editText4);
		edText5 = (EditText) findViewById(R.id.editText5);
		edText6 = (EditText) findViewById(R.id.editText6);
		edText7 = (EditText) findViewById(R.id.editText7);
		edText8 = (EditText) findViewById(R.id.editText8);
		
	 convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (flag ==0){
				
				String edText1Value = edText1.getText().toString();//Then get the string that is currently being displayed
				String edText2Value = edText2.getText().toString();
				String edText3Value = edText3.getText().toString();
				String edText4Value = edText4.getText().toString();	
				String edText5Value = edText5.getText().toString();
				String edText6Value = edText6.getText().toString();
				String edText7Value = edText7.getText().toString();
				String edText8Value = edText8.getText().toString();
							
					if (edText1Value.isEmpty() != true){
						sqm = Double.parseDouble(edText1Value); //Then parse it for a double
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");
											
						flag=1;
					} else if (edText2Value.isEmpty() != true){						
						sqkm = Double.parseDouble(edText2Value); //Then parse it for a double
						edText2.setText(sqkm + " sqkm");
						
						sqm = 1000000*sqkm;
						edText1.setText(sqm + " sqm");						
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");
											
						
						flag=1;
					} else if (edText3Value.isEmpty() != true){						
						sqmile = Double.parseDouble(edText3Value); //Then parse it for a double
						edText3.setText(sqmile + " sqmiles");
						
						sqm = 2590000*sqmile;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");					
												
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");						
						
						flag=1;
					} else if (edText4Value.isEmpty() != true){
						hectare = Double.parseDouble(edText4Value); //Then parse it for a double
						edText4.setText(hectare + " hect");
						
						sqm = 10000*hectare;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
											
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");				
																	
						flag=1;
					} 	else if (edText5Value.isEmpty() != true){
						sqinch = Double.parseDouble(edText5Value); //Then parse it for a double
						edText5.setText(sqinch + " sqin");
						
						sqm = 0.0006452*sqinch;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
												
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");									
						
						flag=1;
					} else if (edText6Value.isEmpty() != true){
						sqfeet = Double.parseDouble(edText6Value); //Then parse it for a double
						edText6.setText(sqfeet + " sqf");
						
						sqm = 0.0929*sqfeet;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");				
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");					
						
						flag=1;
					} else if (edText7Value.isEmpty() != true){
						sqyard = Double.parseDouble(edText7Value); //Then parse it for a double
						edText7.setText(sqyard + " sqyards");
						
						sqm = 0.8361*sqyard;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");			
						
						acre = 0.0002471 *sqm;
						edText8.setText(acre + " acres");					
																							
						flag=1;
					}else if (edText8Value.isEmpty() != true){
						acre = Double.parseDouble(edText8Value); //Then parse it for a double
						edText8.setText(acre + " acres");	
						
						sqm = 4.047*acre;
						edText1.setText(sqm + " sqm");
						
						sqkm = 0.000001 *sqm;
						edText2.setText(sqkm + " sqkm");
						
						sqmile = 0.0000003861 *sqm;
						edText3.setText(sqmile + " sqmiles");
						
						hectare = 0.0001 *sqm;
						edText4.setText(hectare + " hect");
						
						sqinch = 1550 *sqm;
						edText5.setText(sqinch + " sqin");
						
						sqfeet = 10.76 *sqm;
						edText6.setText(sqfeet + " sqf");
						
						sqyard = 1.196 *sqm;
						edText7.setText(sqyard + " sqyards");								
																							
						flag=1;
					}
					
				} else{
					edText1.setText("");
					edText2.setText("");
					edText3.setText("");
					edText4.setText("");
					edText5.setText("");
					edText6.setText("");
					edText7.setText("");
					edText8.setText("");
					flag = 0;					
				}
															
			 }		
			
		 });	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				edText4.setText("");	
				edText5.setText("");
				edText6.setText("");
				edText7.setText("");
				edText8.setText("");
				flag = 0;
			}			
			
		});
		
		
	}


}
