package com.softwarevast.convertme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//FOR ADS
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import twisted_goat.convert_me.R;

public class Temperature extends Activity{
	int flag;
	double c, f, k =0;
	Button convertB, clearB;
	TextView standardTV;
	EditText edText1, edText2, edText3;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_temp);
		// Look up the AdView as a resource and load a request.
				AdView adView = (AdView)this.findViewById(R.id.adView);
				AdRequest adRequest = new AdRequest.Builder().build();
				adView.loadAd(adRequest); 
		
		Class<?> spClass;
		try {
			spClass = Class.forName("com.softwarevast.convertme.TEMP");
			Intent openTEMP = new Intent (Temperature.this, spClass);
			startActivity(openTEMP);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		convertB = (Button) findViewById(R.id.button1);
		clearB = (Button) findViewById(R.id.button2);
		
		standardTV = (TextView) findViewById(R.id.tv01);
		
		edText1 = (EditText) findViewById(R.id.editText1);//First, get an instance of the EditText			
		edText2 = (EditText) findViewById(R.id.editText2);
		edText3 = (EditText) findViewById(R.id.editText3);
				
	 convertB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (flag ==0){
				
				String edText1Value = edText1.getText().toString();//Then get the string that is currently being displayed
				String edText2Value = edText2.getText().toString();
				String edText3Value = edText3.getText().toString();
				
					if (edText1Value.isEmpty() != true){
						c = Double.parseDouble(edText1Value);//Then parse it for a double
						edText1.setText(c +" C");
						
						f = (1.8*c) +32;
						edText2.setText(f + " F");
						
						k = c +273.15;
						edText3.setText(k + " K");					
											
						flag=1;
					} else if (edText2Value.isEmpty() != true){
						
						f = Double.parseDouble(edText2Value);//Then parse it for a double
						edText2.setText(f + " F");
						
						c = 0.5555556 *(f-32);
						edText1.setText(c +" C");					
						
						k = c +273.15;
						edText3.setText(k + " K");								
						
						flag=1;
					} else if (edText3Value.isEmpty() != true){
						k = Double.parseDouble(edText3Value);//Then parse it for a double
						edText3.setText(k + " K");			
						
						c = k -273.15;
						edText1.setText(c +" C");
						
						f = (1.8*c) +32;
						edText2.setText(f + " F");						
						
						flag=1;
					} 
					
				}else{
					edText1.setText("");
					edText2.setText("");
					edText3.setText("");									
					flag = 0;					
				}
															
			 }		
			
		 });	
		
		clearB.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edText1.setText("");
				edText2.setText("");
				edText3.setText("");
				flag = 0;
			}			
			
		});
		
		
	}


}
